// Redirect back to the first page
document.getElementById('go-back-btn').addEventListener('click', () => {
    window.location.href = "index.html"; // Change this if the first page has a different filename
});

// Generate falling confetti
function createConfetti() {
    const confettiContainer = document.querySelector('.confetti-container');

    for (let i = 0; i < 100; i++) {
        const confetti = document.createElement('div');
        confetti.classList.add('confetti');
        confetti.style.left = `${Math.random() * 100}%`;
        confetti.style.animationDelay = `${Math.random() * 3}s`;
        confetti.style.background = `hsl(${Math.random() * 360}, 70%, 60%)`; // Random colorful confetti
        confettiContainer.appendChild(confetti);
    }
}

// Initialize confetti animation
createConfetti();
