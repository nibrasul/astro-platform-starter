document.getElementById('personal-info-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent default form submission behavior

    // Extract user details (optional - for potential processing)
    const name = document.getElementById('name').value;
    const age = document.getElementById('age').value;
    const dob = document.getElementById('dob').value;
    const email = document.getElementById('email').value;

    // Log details if needed (for debugging)
    console.log({ name, age, dob, email });

    // Redirect to the success page
    window.location.href = "success.html";
});
